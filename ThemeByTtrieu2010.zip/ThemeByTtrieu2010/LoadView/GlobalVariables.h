#ifndef GlobalVariables_h
#define GlobalVariables_h

extern MenuLoad *extraInfo;

#endif /* GlobalVariables_h */